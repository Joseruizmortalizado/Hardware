document.addEventListener("DOMContentLoaded", function() {
    var text = document.querySelector(".neon-text");
text.classList.add("animated");
});